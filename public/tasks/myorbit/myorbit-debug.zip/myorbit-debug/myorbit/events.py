"""
Event logging and the in-memory event buffer.
"""

import json
from datetime import datetime

from myorbit.db import execute


class EventBuffer:
    """
    Buffers events in memory before flushing to the database in batches.
    Used by the high-throughput event tracking system.
    """

    # NOTE: class-level state
    _buffer = []

    def __init__(self, max_size=100):
        self.max_size = max_size

    def add(self, event):
        self._buffer.append(event)
        if len(self._buffer) >= self.max_size:
            self.flush()

    def flush(self):
        """Write all buffered events to the database and clear the buffer."""
        for event in self._buffer:
            execute(
                "INSERT INTO events (customer_id, event_type, timestamp, metadata) "
                "VALUES (?, ?, ?, ?)",
                (
                    event["customer_id"],
                    event["event_type"],
                    event["timestamp"],
                    json.dumps(event.get("metadata", {})),
                ),
            )
        self._buffer.clear()

    def size(self):
        return len(self._buffer)


def log_event(customer_id, event_type, metadata=None):
    """
    Log a single engagement event directly to the database.

    Used by the synchronous API endpoint. The batched EventBuffer is for
    bulk ingestion.
    """
    metadata = metadata or {}
    timestamp = datetime.utcnow().isoformat()
    return execute(
        "INSERT INTO events (customer_id, event_type, timestamp, metadata) "
        "VALUES (?, ?, ?, ?)",
        (customer_id, event_type, timestamp, json.dumps(metadata)),
    )
