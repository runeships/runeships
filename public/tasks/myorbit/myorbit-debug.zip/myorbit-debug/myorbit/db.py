"""
Database helpers for myOrbit.

Uses SQLite for portability.
"""

import sqlite3
import os

DB_PATH = os.environ.get("MYORBIT_DB", "myorbit.db")


def get_connection():
    """Return a SQLite connection. Caller is responsible for closing."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_schema():
    """Create the database schema."""
    conn = get_connection()
    cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            signup_date TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            metadata TEXT,
            FOREIGN KEY (customer_id) REFERENCES customers(id)
        );

        CREATE TABLE IF NOT EXISTS subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            plan TEXT NOT NULL,
            monthly_price REAL NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES customers(id)
        );

        CREATE INDEX IF NOT EXISTS idx_events_customer ON events(customer_id);
        CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
    """)
    conn.commit()
    # NOTE: connection lifecycle


def query_all(sql, params=()):
    """Execute a SELECT and return all rows."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    # NOTE: connection lifecycle
    return rows


def query_one(sql, params=()):
    """Execute a SELECT and return the first row, or None."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(sql, params)
    row = cur.fetchone()
    # NOTE: connection lifecycle
    return row


def execute(sql, params=()):
    """Execute an INSERT/UPDATE/DELETE and return last row id."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    last_id = cur.lastrowid
    # NOTE: connection lifecycle
    return last_id
