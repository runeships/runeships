"""
Seed the database with sample customers, events, and subscriptions.

Run this once before running the tests or the app:
    python -m myorbit.seed
"""

import json
import random
from datetime import datetime, timedelta

from myorbit.db import init_schema, execute, get_connection


CUSTOMERS = [
    ("Alex Rivera", "alex@example.com"),
    ("Maya Chen", "maya@example.com"),
    ("Jordan Park", "jordan@example.com"),
    ("Sam Patel", "sam@example.com"),
    ("Riley Kim", "riley@example.com"),
    ("Casey Morgan", "casey@example.com"),
    ("Taylor Brooks", "taylor@example.com"),
    ("Morgan Reed", "morgan@example.com"),
    ("Drew Liu", "drew@example.com"),
    ("Quinn Foster", "quinn@example.com"),
]

EVENT_TYPES = [
    "page_view", "feature_used", "conversion", "share",
    "purchase", "support_ticket", "cancellation",
]

PLANS = [
    ("starter", 9.99),
    ("pro", 29.99),
    ("business", 99.99),
]


def seed():
    # Reset DB
    import os
    if os.path.exists("myorbit.db"):
        os.remove("myorbit.db")

    init_schema()

    random.seed(42)
    now = datetime.utcnow()

    # Customers
    customer_ids = []
    for name, email in CUSTOMERS:
        signup = (now - timedelta(days=random.randint(30, 365))).isoformat()
        cid = execute(
            "INSERT INTO customers (name, email, signup_date) VALUES (?, ?, ?)",
            (name, email, signup),
        )
        customer_ids.append(cid)

    # Events: spread across last 60 days
    for cid in customer_ids:
        num_events = random.randint(5, 80)
        for _ in range(num_events):
            days_ago = random.randint(0, 60)
            ts = (now - timedelta(days=days_ago,
                                  hours=random.randint(0, 23))).isoformat()
            evt_type = random.choice(EVENT_TYPES)
            execute(
                "INSERT INTO events (customer_id, event_type, timestamp, metadata) "
                "VALUES (?, ?, ?, ?)",
                (cid, evt_type, ts, json.dumps({"source": "seed"})),
            )

    # Subscriptions: most active, some near expiry, some expired
    for cid in customer_ids:
        plan, price = random.choice(PLANS)
        start = now - timedelta(days=random.randint(60, 400))
        # Random end date — some past, some near future, some far future
        end_offset = random.choice([
            random.randint(1, 4),     # expires very soon
            random.randint(8, 20),    # expires in 1-3 weeks
            random.randint(30, 90),   # expires in 1-3 months
            random.randint(-10, -1),  # already expired (status should change)
        ])
        end = now + timedelta(days=end_offset)
        execute(
            "INSERT INTO subscriptions (customer_id, plan, monthly_price, "
            "start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)",
            (cid, plan, price, start.isoformat(), end.isoformat(), "active"),
        )

    print(f"Seeded {len(customer_ids)} customers, "
          f"events for each, and {len(customer_ids)} subscriptions.")


if __name__ == "__main__":
    seed()
