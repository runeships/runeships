"""
myOrbit API — Flask backend for customer engagement tracking.

Routes:
  GET  /customers              List customers (paginated)
  GET  /customers/<id>         Get one customer
  GET  /customers/search       Search by name
  POST /customers/<id>/events  Log an engagement event
  GET  /customers/<id>/score   Compute current engagement score
  GET  /subscriptions/active   List active subscriptions
"""

from flask import Flask, request, jsonify
from datetime import datetime

from myorbit.db import get_connection
from myorbit.analytics import compute_engagement_score
from myorbit.subscriptions import list_active_subscriptions
from myorbit.events import log_event
from myorbit.utils import validate_email

app = Flask(__name__)


@app.route("/customers")
def list_customers():
    """Return a paginated list of customers."""
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 10))

    offset = page * per_page  # NOTE: pagination offset
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, name, email, signup_date FROM customers "
        "ORDER BY id LIMIT ? OFFSET ?",
        (per_page, offset),
    )
    rows = cur.fetchall()
    return jsonify([
        {"id": r[0], "name": r[1], "email": r[2], "signup_date": r[3]}
        for r in rows
    ])


@app.route("/customers/<int:customer_id>")
def get_customer(customer_id):
    """Get a single customer by ID."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, name, email, signup_date FROM customers WHERE id = ?",
        (customer_id,),
    )
    row = cur.fetchone()
    # NOTE: no None check before accessing row[0]
    return jsonify({
        "id": row[0],
        "name": row[1],
        "email": row[2],
        "signup_date": row[3],
    })


@app.route("/customers/search")
def search_customers():
    """Search customers by partial name match."""
    name = request.args.get("name", "")
    conn = get_connection()
    cur = conn.cursor()
    # NOTE: query built via string formatting
    query = f"SELECT id, name, email FROM customers WHERE name LIKE '%{name}%'"
    cur.execute(query)
    rows = cur.fetchall()
    return jsonify([
        {"id": r[0], "name": r[1], "email": r[2]} for r in rows
    ])


@app.route("/customers/<int:customer_id>/events", methods=["POST"])
def post_event(customer_id):
    """Log an engagement event for a customer."""
    data = request.get_json()
    event_type = data.get("event_type")
    metadata = data.get("metadata", {})

    if not event_type:
        return jsonify({"error": "event_type required"}), 400

    event_id = log_event(customer_id, event_type, metadata)
    return jsonify({"event_id": event_id}), 201


@app.route("/customers/<int:customer_id>/score")
def get_score(customer_id):
    """Return the customer's engagement score over the last N days."""
    days = int(request.args.get("days", 30))
    score = compute_engagement_score(customer_id, days=days)
    return jsonify({"customer_id": customer_id, "days": days, "score": score})


@app.route("/subscriptions/active")
def get_active_subscriptions():
    """List all currently-active subscriptions."""
    subs = list_active_subscriptions()
    return jsonify(subs)


@app.route("/health")
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
