"""
Subscription management and billing for myOrbit.
"""

from datetime import datetime, timedelta, timezone

from myorbit.db import query_all, query_one, execute


def list_active_subscriptions():
    """Return all subscriptions with status 'active'."""
    today = datetime.now()
    rows = query_all(
        "SELECT id, customer_id, plan, monthly_price, start_date, end_date, status "
        "FROM subscriptions WHERE status = 'active'"
    )

    result = []
    for row in rows:
        sub_id, cust_id, plan, price, start, end, status = row
        end_dt = datetime.fromisoformat(end)

        # NOTE: check expiry condition
        if end_dt <= today:
            execute(
                "UPDATE subscriptions SET status = 'expired' WHERE id = ?",
                (sub_id,),
            )
            continue

        result.append({
            "id": sub_id,
            "customer_id": cust_id,
            "plan": plan,
            "monthly_price": price,
            "start_date": start,
            "end_date": end,
        })
    return result


def calculate_invoice(customer_id):
    """
    Calculate total invoice amount for a customer.

    Sums all active subscriptions plus prorated charges for the current
    partial month.
    """
    subs = query_all(
        "SELECT monthly_price, start_date, end_date FROM subscriptions "
        "WHERE customer_id = ? AND status = 'active'",
        (customer_id,),
    )

    total = 0.0
    for price, start, end in subs:
        total += price

    # Apply 8% tax
    tax = total * 0.08
    grand_total = total + tax
    return {
        "subtotal": total,
        "tax": tax,
        "total": grand_total,
    }


def renew_subscription(subscription_id, months=12):
    """Extend a subscription by N months past its current end date."""
    row = query_one(
        "SELECT end_date FROM subscriptions WHERE id = ?",
        (subscription_id,),
    )
    if not row:
        raise ValueError(f"Subscription {subscription_id} not found")

    current_end = datetime.fromisoformat(row[0])
    # Approximate 30 days per month
    new_end = current_end + timedelta(days=30 * months)

    execute(
        "UPDATE subscriptions SET end_date = ?, status = 'active' WHERE id = ?",
        (new_end.isoformat(), subscription_id),
    )
    return new_end.isoformat()


def subscriptions_expiring_soon(within_days=7):
    """
    Return subscriptions whose end_date is within `within_days` from now.

    Used for the daily expiry notification job.
    """
    # Note: timestamps in the DB are stored with timezone offsets (e.g.,
    # "2025-06-20T14:30:00+00:00") because they originated from event
    # tracking which is timezone-aware.
    now = datetime.now()
    horizon = now + timedelta(days=within_days)

    rows = query_all(
        "SELECT id, customer_id, plan, end_date FROM subscriptions "
        "WHERE status = 'active' AND end_date <= ?",
        (horizon.isoformat(),),
    )

    expiring = []
    for sub_id, cust_id, plan, end in rows:
        end_dt = datetime.fromisoformat(end)
        if end_dt >= now:  # not yet expired
            expiring.append({
                "id": sub_id,
                "customer_id": cust_id,
                "plan": plan,
                "end_date": end,
                "days_remaining": (end_dt - now).days,
            })
    return expiring
