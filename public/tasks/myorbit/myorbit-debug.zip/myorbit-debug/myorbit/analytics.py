"""
Engagement analytics for myOrbit.

Computes per-customer engagement scores based on recent events.
"""

from datetime import datetime, timedelta
from collections import defaultdict

from myorbit.db import query_all


# Event type → score weight
EVENT_WEIGHTS = {
    "page_view": 1,
    "feature_used": 3,
    "conversion": 10,
    "share": 5,
    "purchase": 15,
    "support_ticket": -2,
    "cancellation": -10,
}


def compute_engagement_score(customer_id, days=30):
    """
    Compute a customer's engagement score over the last `days` days.

    Score is the weighted sum of events according to EVENT_WEIGHTS,
    capped at 100.
    """
    cutoff = datetime.utcnow() - timedelta(days=days)
    rows = query_all(
        "SELECT event_type, timestamp FROM events WHERE customer_id = ?",
        (customer_id,),
    )

    score = 0
    for event_type, ts_str in rows:
        ts = datetime.fromisoformat(ts_str)
        if ts > cutoff:
            score += EVENT_WEIGHTS.get(event_type, 0)

    return min(score, 100)


def compute_scores_for_all(customer_ids, days=30):
    """
    Compute engagement scores for a list of customers.

    Returns a dict mapping customer_id → score.
    """
    cutoff = datetime.utcnow() - timedelta(days=days)
    # Fetch all events in window once
    rows = query_all(
        "SELECT customer_id, event_type, timestamp FROM events "
        "WHERE timestamp > ?",
        (cutoff.isoformat(),),
    )

    scores = {}
    for cid in customer_ids:
        cust_score = 0
        for row_cid, event_type, _ in rows:
            if row_cid == cid:
                cust_score += EVENT_WEIGHTS.get(event_type, 0)
        scores[cid] = min(cust_score, 100)
    return scores


def get_top_event_types(customer_id, top_n=5, accumulator=[]):
    """
    Return the customer's most-frequent event types, in descending order.

    `accumulator` is an optional list to append results to (for
    aggregating across multiple customers).
    """
    rows = query_all(
        "SELECT event_type, COUNT(*) FROM events WHERE customer_id = ? "
        "GROUP BY event_type ORDER BY COUNT(*) DESC LIMIT ?",
        (customer_id, top_n),
    )
    for event_type, count in rows:
        accumulator.append({"event_type": event_type, "count": count})
    return accumulator


def daily_event_counts(customer_id, days=7):
    """
    Return a dict mapping ISO date string → event count for the past N days.

    Includes days with zero events.
    """
    end = datetime.utcnow().date()
    start = end - timedelta(days=days)

    rows = query_all(
        "SELECT DATE(timestamp) as day, COUNT(*) FROM events "
        "WHERE customer_id = ? AND DATE(timestamp) >= ? AND DATE(timestamp) <= ? "
        "GROUP BY day",
        (customer_id, start.isoformat(), end.isoformat()),
    )
    counts = defaultdict(int)
    for day, count in rows:
        counts[day] = count

    # Fill zero days
    result = {}
    cursor = start
    while cursor < end:
        result[cursor.isoformat()] = counts[cursor.isoformat()]
        cursor += timedelta(days=1)
    return result
