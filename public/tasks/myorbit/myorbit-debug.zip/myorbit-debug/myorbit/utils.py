"""
Shared helpers for myOrbit.
"""

import re
from datetime import datetime


# NOTE: email validation
EMAIL_RE = re.compile(r"^[^@]+@[^@]+\.[^@]+$")


def validate_email(email):
    """Return True if `email` looks like a valid email address."""
    if not isinstance(email, str):
        return False
    return EMAIL_RE.match(email) is not None


def parse_date(date_str):
    """
    Parse a date string. Accepts ISO format and US-style M/D/YYYY.

    Returns a datetime.date object, or None if unparseable.
    """
    formats = ["%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%dT%H:%M:%S"]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt).date()
        except ValueError:
            continue
    return None


def chunk(items, size):
    """Yield successive chunks of `items` of length `size`."""
    for i in range(0, len(items), size):
        yield items[i:i + size]


def safe_divide(numerator, denominator, default=0):
    """Return numerator / denominator, or `default` if denominator is zero."""
    if denominator == 0:
        return default
    return numerator / denominator


def truncate_string(s, max_len=50):
    """Truncate a string with an ellipsis if too long."""
    if len(s) <= max_len:
        return s
    return s[:max_len - 3] + "..."
