"""
Tests for myorbit.events

Some of these tests are FAILING because of bugs in the code.
Your job is to fix the bugs so the tests pass — do NOT modify the tests.
"""

import pytest

from myorbit.events import EventBuffer


def test_buffer_starts_empty():
    """A fresh EventBuffer should have zero events."""
    buf = EventBuffer(max_size=10)
    assert buf.size() == 0


def test_buffer_isolated_between_instances():
    """
    Two separate EventBuffer instances should NOT share state.
    Adding to one must not affect the other.
    """
    buf_a = EventBuffer(max_size=10)
    buf_b = EventBuffer(max_size=10)

    buf_a.add({
        "customer_id": 1,
        "event_type": "page_view",
        "timestamp": "2025-06-01T12:00:00",
    })

    assert buf_a.size() == 1
    assert buf_b.size() == 0, (
        f"buf_b should be empty but has {buf_b.size()} event(s). "
        "EventBuffer instances are sharing state!"
    )


def test_buffer_size_increments():
    buf = EventBuffer(max_size=100)
    for i in range(5):
        buf.add({
            "customer_id": i,
            "event_type": "page_view",
            "timestamp": "2025-06-01T12:00:00",
        })
    assert buf.size() == 5
