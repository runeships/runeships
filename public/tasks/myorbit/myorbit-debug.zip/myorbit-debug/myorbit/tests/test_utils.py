"""
Tests for myorbit.utils

Some of these tests are FAILING because of bugs in the code.
Your job is to fix the bugs so the tests pass — do NOT modify the tests.
"""

import pytest
from datetime import date

from myorbit.utils import validate_email, parse_date, chunk, safe_divide


# ─── validate_email ────────────────────────────────────────────

def test_validate_email_accepts_valid():
    assert validate_email("user@example.com") is True
    assert validate_email("first.last@company.co.uk") is True
    assert validate_email("name+tag@gmail.com") is True


def test_validate_email_rejects_invalid():
    # Missing @
    assert validate_email("notanemail") is False
    # Missing local part
    assert validate_email("@example.com") is False
    # Missing domain
    assert validate_email("user@") is False
    # Missing TLD
    assert validate_email("user@example") is False
    # Spaces
    assert validate_email("user @example.com") is False
    # Empty
    assert validate_email("") is False


def test_validate_email_rejects_non_strings():
    assert validate_email(None) is False
    assert validate_email(12345) is False
    assert validate_email([]) is False


# ─── parse_date ────────────────────────────────────────────────

def test_parse_date_iso():
    assert parse_date("2024-03-15") == date(2024, 3, 15)


def test_parse_date_european_format():
    # 15/03/2024 means March 15 — day/month/year
    assert parse_date("15/03/2024") == date(2024, 3, 15)


def test_parse_date_unparseable():
    assert parse_date("not a date") is None
    assert parse_date("") is None


# ─── chunk ─────────────────────────────────────────────────────

def test_chunk_even():
    assert list(chunk([1, 2, 3, 4, 5, 6], 2)) == [[1, 2], [3, 4], [5, 6]]


def test_chunk_uneven():
    assert list(chunk([1, 2, 3, 4, 5], 2)) == [[1, 2], [3, 4], [5]]


# ─── safe_divide ───────────────────────────────────────────────

def test_safe_divide_normal():
    assert safe_divide(10, 2) == 5


def test_safe_divide_by_zero():
    assert safe_divide(10, 0) == 0
    assert safe_divide(10, 0, default=-1) == -1
