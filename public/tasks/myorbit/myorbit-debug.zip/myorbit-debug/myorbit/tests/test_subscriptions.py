"""
Tests for myorbit.subscriptions

Some of these tests are FAILING because of bugs in the code.
Your job is to fix the bugs so the tests pass — do NOT modify the tests.
"""

import pytest
from datetime import datetime, timedelta
from decimal import Decimal

from myorbit.db import init_schema, execute


@pytest.fixture(autouse=True)
def fresh_db(tmp_path, monkeypatch):
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("MYORBIT_DB", db_path)
    import importlib
    from myorbit import db as db_mod
    importlib.reload(db_mod)
    from myorbit import subscriptions
    importlib.reload(subscriptions)
    db_mod.init_schema()
    yield db_path


def _make_customer():
    return execute(
        "INSERT INTO customers (name, email, signup_date) VALUES (?, ?, ?)",
        ("Test", "test@example.com", datetime.utcnow().isoformat()),
    )


def _make_subscription(cid, plan, price, days_until_end, status="active"):
    start = datetime.utcnow() - timedelta(days=60)
    end = datetime.utcnow() + timedelta(days=days_until_end)
    return execute(
        "INSERT INTO subscriptions (customer_id, plan, monthly_price, "
        "start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)",
        (cid, plan, price, start.isoformat(), end.isoformat(), status),
    )


# ─── calculate_invoice ─────────────────────────────────────────

def test_invoice_single_subscription():
    from myorbit.subscriptions import calculate_invoice
    cid = _make_customer()
    _make_subscription(cid, "pro", 29.99, days_until_end=30)
    invoice = calculate_invoice(cid)
    assert invoice["subtotal"] == 29.99
    assert round(invoice["tax"], 2) == 2.40
    assert round(invoice["total"], 2) == 32.39


def test_invoice_multiple_subscriptions_no_floating_point_error():
    """
    Summing decimal prices must not produce floating-point artifacts.
    These specific amounts trigger the classic IEEE 754 issue:
    0.10 + 0.20 != 0.30 when using float.
    Billing code should use Decimal, not float.
    """
    from myorbit.subscriptions import calculate_invoice
    cid = _make_customer()
    _make_subscription(cid, "addon_a", 0.10, days_until_end=30)
    _make_subscription(cid, "addon_b", 0.20, days_until_end=30)
    invoice = calculate_invoice(cid)
    # With float: 0.10 + 0.20 = 0.30000000000000004 (not 0.30)
    # With Decimal: exactly 0.30
    assert invoice["subtotal"] == 0.30, (
        f"Expected exactly 0.30, got {invoice['subtotal']!r} — "
        "billing arithmetic should use Decimal, not float"
    )


# ─── list_active_subscriptions ─────────────────────────────────

def test_subscription_expires_AFTER_end_date_not_ON_it():
    """
    A subscription whose end_date is TODAY should still be considered
    active. It expires AFTER that date, not on it.
    """
    from myorbit.subscriptions import list_active_subscriptions
    cid = _make_customer()
    # Subscription ending today (0 days from now)
    sub_id = _make_subscription(cid, "pro", 29.99, days_until_end=0)

    active = list_active_subscriptions()
    sub_ids = [s["id"] for s in active]
    assert sub_id in sub_ids, (
        "A subscription ending today should still be active. "
        "It expires the day AFTER the end date."
    )


def test_subscription_truly_expired_is_excluded():
    from myorbit.subscriptions import list_active_subscriptions
    cid = _make_customer()
    # Subscription ended 5 days ago
    sub_id = _make_subscription(cid, "pro", 29.99, days_until_end=-5)

    active = list_active_subscriptions()
    sub_ids = [s["id"] for s in active]
    assert sub_id not in sub_ids


# ─── renew_subscription ────────────────────────────────────────

def test_renew_extends_end_date():
    from myorbit.subscriptions import renew_subscription
    from myorbit.db import query_one

    cid = _make_customer()
    sub_id = _make_subscription(cid, "pro", 29.99, days_until_end=10)

    new_end_str = renew_subscription(sub_id, months=12)
    new_end = datetime.fromisoformat(new_end_str)

    # Original end was 10 days from now; new end is 10 + 360 days ≈ 370 days
    expected_min = datetime.utcnow() + timedelta(days=365)
    assert new_end > expected_min
