"""
Tests for myorbit.analytics

Some of these tests are FAILING because of bugs in the code.
Your job is to fix the bugs so the tests pass — do NOT modify the tests.
"""

import json
import os
import pytest
from datetime import datetime, timedelta

from myorbit.db import init_schema, execute
from myorbit.analytics import (
    compute_engagement_score,
    compute_scores_for_all,
    get_top_event_types,
    daily_event_counts,
)


@pytest.fixture(autouse=True)
def fresh_db(tmp_path, monkeypatch):
    """Use a fresh DB for each test."""
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("MYORBIT_DB", db_path)
    # Reload the module to pick up new env var
    import importlib
    from myorbit import db as db_mod
    importlib.reload(db_mod)
    from myorbit import analytics
    importlib.reload(analytics)
    db_mod.init_schema()
    yield db_path


def _insert_customer(name, email):
    return execute(
        "INSERT INTO customers (name, email, signup_date) VALUES (?, ?, ?)",
        (name, email, datetime.utcnow().isoformat()),
    )


def _insert_event(customer_id, event_type, days_ago=0):
    ts = (datetime.utcnow() - timedelta(days=days_ago)).isoformat()
    return execute(
        "INSERT INTO events (customer_id, event_type, timestamp, metadata) "
        "VALUES (?, ?, ?, ?)",
        (customer_id, event_type, ts, json.dumps({})),
    )


# ─── compute_engagement_score ──────────────────────────────────

def test_engagement_score_basic():
    cid = _insert_customer("Test", "test@example.com")
    # 3 page views (weight 1 each), 1 conversion (weight 10)
    _insert_event(cid, "page_view", days_ago=2)
    _insert_event(cid, "page_view", days_ago=3)
    _insert_event(cid, "page_view", days_ago=4)
    _insert_event(cid, "conversion", days_ago=1)
    score = compute_engagement_score(cid, days=30)
    assert score == 13


def test_engagement_score_excludes_old_events():
    cid = _insert_customer("Test", "test@example.com")
    _insert_event(cid, "purchase", days_ago=2)   # weight 15, included
    _insert_event(cid, "purchase", days_ago=50)  # weight 15, EXCLUDED (>30 days)
    score = compute_engagement_score(cid, days=30)
    assert score == 15


def test_engagement_score_includes_boundary_event():
    """An event from exactly N days ago must be INCLUDED in the N-day window."""
    cid = _insert_customer("Test", "test@example.com")
    # Event from exactly 7 days ago
    _insert_event(cid, "conversion", days_ago=7)
    score = compute_engagement_score(cid, days=7)
    assert score == 10, "Event at exactly the boundary should be included"


def test_engagement_score_capped_at_100():
    cid = _insert_customer("Test", "test@example.com")
    for _ in range(20):
        _insert_event(cid, "purchase", days_ago=1)
    score = compute_engagement_score(cid, days=30)
    assert score == 100


# ─── compute_scores_for_all ────────────────────────────────────

def test_compute_scores_for_all_returns_correct_per_customer():
    a = _insert_customer("A", "a@example.com")
    b = _insert_customer("B", "b@example.com")
    c = _insert_customer("C", "c@example.com")

    _insert_event(a, "page_view", days_ago=1)  # +1
    _insert_event(a, "conversion", days_ago=2)  # +10
    _insert_event(b, "purchase", days_ago=3)   # +15
    _insert_event(c, "support_ticket", days_ago=1)  # -2

    scores = compute_scores_for_all([a, b, c], days=30)
    assert scores[a] == 11
    assert scores[b] == 15
    assert scores[c] == -2


# ─── get_top_event_types ───────────────────────────────────────

def test_get_top_event_types_isolated_per_call():
    """
    Multiple calls to get_top_event_types must NOT share state.
    Each call should return only that customer's results.
    """
    a = _insert_customer("A", "a@example.com")
    b = _insert_customer("B", "b@example.com")

    _insert_event(a, "page_view")
    _insert_event(a, "page_view")
    _insert_event(b, "purchase")
    _insert_event(b, "purchase")
    _insert_event(b, "purchase")

    result_a = get_top_event_types(a, top_n=5)
    result_b = get_top_event_types(b, top_n=5)

    # First call should have just A's events
    assert len(result_a) == 1
    assert result_a[0]["event_type"] == "page_view"

    # Second call should have just B's events — NOT polluted by A's
    assert len(result_b) == 1, (
        f"Expected only B's results, got {len(result_b)}: {result_b}"
    )
    assert result_b[0]["event_type"] == "purchase"


# ─── daily_event_counts ────────────────────────────────────────

def test_daily_event_counts_includes_zero_days():
    cid = _insert_customer("Test", "test@example.com")
    _insert_event(cid, "page_view", days_ago=2)
    counts = daily_event_counts(cid, days=7)
    # Should have an entry for every day in the 7-day window
    assert len(counts) == 7
