# myOrbit — Customer Engagement Backend

A small Python/Flask backend that powers myOrbit's customer engagement
tracking platform. Tracks customer events, computes engagement scores,
and manages subscriptions.

## Stack

- Python 3.10+
- Flask (HTTP API)
- SQLite (storage, via stdlib `sqlite3`)
- pytest (testing)

## Setup

```bash
python -m venv venv
source venv/bin/activate    # on Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m myorbit.seed      # populate sample data
```

## Run the API

```bash
python -m myorbit.app
# server listens on http://localhost:5000
```

## Run the tests

```bash
pytest
```

## Project structure

```
myorbit/
├── app.py              # Flask routes
├── db.py               # SQLite helpers + schema
├── analytics.py        # Engagement score computation
├── subscriptions.py    # Subscription + billing logic
├── events.py           # Event logging + in-memory buffer
├── utils.py            # Validation + helpers
├── seed.py             # Sample data loader
└── tests/
    ├── test_utils.py
    ├── test_analytics.py
    ├── test_subscriptions.py
    └── test_events.py
```

## What it does

The platform tracks customer behavior:

- **Customers** sign up and create accounts
- **Events** (page views, feature use, purchases, support tickets, etc.)
  are logged against each customer
- **Engagement scores** are computed from recent events, weighted by
  event type, and capped at 100
- **Subscriptions** are billed monthly, with tax applied; they expire
  on their `end_date` and renewals extend them by N months

## See `BUGS.md` for the task you're being assessed on.
