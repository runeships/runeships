# Known issues — find and fix

Hey, welcome to the codebase. We've got production bugs piling up and we need
help triaging and fixing them. Here are the symptoms our users and team have
reported. Some are obvious; some are subtle. Your job is to find each one,
understand the root cause, and fix it.

**Ground rules**

- Don't modify the tests. They encode the correct behavior.
- Fix the code so all tests pass.
- Some bugs aren't caught by tests but are still in the code. Find them too
  by reading carefully — they're real issues we'll catch in code review.
- We care more about clean, correct fixes than fast ones. Comment your fixes
  with `# FIX:` explaining what was wrong and why your fix works.

## Reported issues

### 1. Pagination is broken

When users hit `GET /customers?page=1`, they get customers 11-20 instead of
the first page. Page 2 returns customers 21-30. Something's off with how the
offset is calculated.

### 2. The API crashes when looking up a customer that doesn't exist

`GET /customers/9999` returns a 500 error instead of a clean 404 when the
customer ID isn't in the database. This started happening after a refactor.

### 3. Customer search has a security smell

One of our senior engineers flagged the `/customers/search` endpoint during
review. They said something about "the way we build the LIKE query." Worth
investigating — feels like a real vulnerability.

### 4. The engagement score for the last 7 days seems off by one day

When customers do work on day -7 from now (a week ago today), it doesn't
show up in their 7-day engagement score. The boundary day is being missed.

### 5. `get_top_event_types` returns wrong results on repeated calls

If you call `get_top_event_types(customer_a)` and then
`get_top_event_types(customer_b)`, the second call returns BOTH customers'
events mixed together. Calling it again returns even more. State is leaking.

### 6. Engagement leaderboard endpoint is incredibly slow

When the team tried to compute scores for all 5,000 customers at once
using `compute_scores_for_all`, the request took over 90 seconds. We
suspect the loop is doing more work than it needs to. There's a more
efficient approach using a different data structure.

### 7. Invoice totals occasionally show like 59.97000000000001

Several customers have complained that their invoice line items end with
weird trailing decimals. Sometimes the displayed total is one cent off
from what we expected. This is a precision issue with how we sum prices.

### 8. Subscriptions are expiring one day early

A user reported their pro plan ended on June 15 when the end date in the
system was June 15. They said they should have had access THROUGH June 15,
not be cut off AT the start of June 15. Check the expiration logic.

### 9. EventBuffer instances are sharing state

Our high-throughput event ingestion has a weird issue. The team noticed
that when they create multiple `EventBuffer` instances (for different
worker threads), events added to one buffer somehow appear in the others.
It's like they're all writing to the same underlying list.

### 10. Email validation accepts obviously broken addresses

The signup form lets users register with emails like `user@example` (no
TLD), `user@` (no domain), or `@example.com` (no local part). All of
these should be rejected before they hit the database. The regex needs
work.

### 11. Date parsing is silently flipping months and days

When users from the EU enter dates like `15/03/2024`, they're being
parsed correctly. But when users from the US enter `03/15/2024`, the
parser is returning a `ValueError` (eventually returning `None`). The
function tries multiple formats but the US format isn't in the list of
formats it tries. Either add support for it OR make the bug visible to
the user — your call which is the right fix here.

### 12. We're leaking DB connections

Our ops team noticed `sqlite3.OperationalError: database is locked`
errors spiking when traffic increases. Looking at the code, our DB
helpers in `db.py` open connections but never close them. Under load,
the connection pool fills up. We need proper resource cleanup — context
managers are the idiomatic Python way to handle this.

---

**Submission**

When you're done:

1. Make sure `pytest` runs clean — all tests pass
2. Add `# FIX:` comments next to every fix you made, briefly explaining
   the bug and your reasoning
3. Submit a link to your fixed code (GitHub repo, public Gist, or a zip
   uploaded to Google Drive / Dropbox with public sharing enabled)
4. If you couldn't fix a particular bug, document what you tried and
   what you'd try next given more time

Expected time: 3-5 hours of focused work. There are 12 issues listed
above. A strong submission catches and fixes most of them; an
exceptional one catches additional issues we didn't flag here.
